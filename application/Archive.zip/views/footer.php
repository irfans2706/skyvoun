<!--Footer Section-->
<img src="<?=base_url()?>resources/img/Asset 4.png" alt="">
        <div class="footer">
            <div class="container-fluid">
                <div class="container">
                    <div class="footer-info">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 text-center">
                                <a href="<?=base_url()?>" class="footer-logo"><img src="<?=base_url()?>resources/img/lctip.png" width="200" style="background-color: white;border-radius: 20px;padding: 10px;"></a>
                                <div class="footer-social">
                                    <a href="https://line.me/ti/p/~@rmk5067o"><i class="flaticon-line-logo"></i></a>
                                    <a href="https://instagram.com/lctipipb"><i class="flaticon-instagram"></i></a>
                                    <a href="https://twitter.com/lctipipb"><i class="flaticon-twitter"></i></a>
                                    <a href="https://facebook.com/lctipipbku"><i class="flaticon-facebook-circular-logo"></i></a>
                                    <a href="mailto:lctip@apps.ipb.ac.id?subject=Ask%20LCTIP%20XXIX&body=Halo%20LCTIP%20XXIX%2C%20saya%20mau%20bertanya.."><i class="flaticon-email"></i></a>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <h2>Contact Us</h2>
                                <h3><i class="flaticon-whatsapp"></i>+62 878 7489 2487 (Shila)</h3>
                                <h3><i class="flaticon-whatsapp"></i>+62 812 8867 2739 (Levina)</h3>
                                <h3><i class="flaticon-line-logo"></i>silaslsbl</h3>
                                <h3><i class="flaticon-line-logo"></i>levinaptr</h3>
                                <h3><i class="flaticon-email"></i>lctip@apps.ipb.ac.id</h3>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <h3>Sekretariat HIMITEPA</h3>
                                <h3>Lantai dasar gedung Fakultas Teknologi Pertanian</h3>
                                <h3>Kampus IPB Dramaga, Bogor</h3>
                            </div>
                        </div>
                    </div>
                    <div class="container copyright">
                        <div class="row">
                            <div class="col-md-6">
                                <p>&copy; <a href="#">LCTIP</a>, All Right Reserved.</p>
                            </div>
                            <div class="col-md-6">
                                <p>Designed By <a href="<?=base_url()?>">GI Tech</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Footer-->
    </div>
</body>

</html>