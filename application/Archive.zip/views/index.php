<!--Banner Section-->
<section class="banner-section bg-banner">
            <div class="container pt-7">
                <div class="content">
                    <p class="h4">HIMITEPA IPB</p>
                    <p class="h1">Lomba Cepat Tepat<br>Ilmu Pangan XXIX</p>
                    <div class="btn-box">
                        <a href="<?=base_url()?>registration">
                            <button class="theme-btn btn-style-two">
                                <span class="btn-title">Register</span>
                            </button>
                        </a>
                        <a href="<?=base_url()?>competition">
                            <button class="theme-btn btn-style-five">
                                <span class="btn-title">Discover</span>
                            </button>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <!--End Banner Section-->
        
        <!--About Start-->
        <div class="about-section mt-5">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="row mb-5 justify-content-center">
                            <div class="col-12 text-center p-3" style="background: #993366">
                                <p class="text-white mb-0">Try Out Online dapat diakses pada <a href="https://tryout.lctipipb.com/" target="_blank">link</a> pada tanggal 21-22 Agustus</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7 col-md-6">
                        <div class="about-img">
                            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                    <div class="carousel-item active">
                                        <img src="<?=base_url()?>resources/img/foto competition/IMG_9371.JPG" class="d-block w-100" alt="image">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?=base_url()?>resources/img/foto competition/IMG_9367.JPG" class="d-block w-100" alt="image">
                                    </div>
                                    <div class="carousel-item">
                                        <img src="<?=base_url()?>resources/img/foto seminar/IMG_9389.JPG" class="d-block w-100" alt="image">
                                    </div>
                                </div>
                                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Previous</span>
                                </a>
                                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="sr-only">Next</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-6">
                        <div class="section-header text-left" style="position: relative;">
                            <p class="h4">About</p>
                            <p class="h1">LCTIP XXIX</p>
                            <img class="d-none" src="<?=base_url()?>resources/img/clipart/plant bun.png" style="width: 100px;position: absolute;left: -10px;top: -90px;">
                            <img src="<?=base_url()?>resources/img/gradasi.png" style="width: 500px;position: absolute;right: -300px;top: -300px;z-index: -1;opacity: 60%;">
                        </div>
                        <div class="about-text text-justify">
                            <p>
                                <b>The biggest annual food science and technology competition</b> for high school students all over Indonesia held by Himpunan Mahasiswa Ilmu dan Teknologi Pangan IPB with a marvelous series of events. This year, we are back with a brand new breeze to bring out the fight and fun from you through screens (online)!
                            </p>
                            <div class="btn-box">
                                <a href="<?=base_url()?>registration" class="theme-btn btn-style-one">
                                    <span class="btn-title">Register</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->

        <!--Events Section-->
        <div class="events-section">
            <div class="container">
                <div class="section-header text-center" style="position: relative;">
                    <p class="h1">Event</p>
                    <img src="<?=base_url()?>resources/img/gradasi.png" style="width: 600px;position: absolute;left: -450px;top: -300px;z-index: -1;opacity: 60%;">
                </div>

                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch wow fadeInUp" data-wow-delay="0.2s">
                        <div class="item bg-white">
                            <div class="icon">
                                <i class="flaticon-trophy-1"></i>
                            </div>
                            <p class="h3">Competition</p>
                            <p>
                                Kompetisi LCTIP XXIX merupakan lomba cepat tepat terkait ilmu pangan yang terdiri atas beberapa babak ditujukan spesial bagi siswa/i SMA/Sederajat yang memiliki ketertarikan dalam bidang pangan.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch wow fadeInUp" data-wow-delay="0.2s">
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-boss"></i>
                            </div>
                            <p class="h3">National Seminar</p>
                            <p>
                                Seminar utama LCTIP XXIX mengangkat tema <i>Exploring Through The Plant-Based Wonders for Conscious and Sustainable Prospects.</i>
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 d-flex align-items-stretch wow fadeInUp" data-wow-delay="0.4s">
                        <div class="item">
                            <div class="icon">
                                <i class="flaticon-goal-1"></i>
                            </div>
                            <p class="h3">Pare Challenge</p>
                            <p>
                                PARE <i>Challenge</i>, atau <i>Plant-Based Right Here Challenge</i>, merupakan wadah penyampaian aspirasi mengenai aplikasi <i>plant-based diet</i> yang mudah dilakukan dalam kehidupan sehari-hari sekaligus gerakan untuk mengajak masyarakat beralih ke <i>plant-based diet</i>.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Events Section-->

        <!--Timeline Section-->
        <div class="timeline-section">
            <div class="container">
                <div class="section-header text-center">
                    <p class="h4">timeline</p>
                    <p class="h1">LCTIP XXIX</p>
                </div>
                <div class="timeline-img">
                    <div class ="timeline-item" style="position: relative;">
                        <img src="<?=base_url()?>resources/img/Timeline LCTIP.png" style="max-height: 450px;" width="auto">
                        <img class="timeline-clipart-1" src="<?=base_url()?>resources/img/clipart/PibiHungryBG.png">
                        <img class="timeline-clipart-2" src="<?=base_url()?>resources/img/clipart/PibiMain1BG.png">
                    </div>
                </div>
            </div>
        </div>
        <!--End Timeline Section-->

        <!--Profil Section-->
        <div class="profil-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-12">
                        <div class="section-header text-left">
                            <p class="h4">Penyelenggara</p>
                            <p class="h1">LCTIP XXIX</p>
                        </div>
                        <div class="profil-text text-justify">
                            <p>
                                Acara ini diselenggarakan oleh <b>Himpunan Mahasiswa Ilmu dan Teknologi Pangan (HIMITEPA)</b> dari Departemen Ilmu dan Teknologi Pangan IPB University, sebagai pionir dalam memecahkan masalah terkait pangan yang terbagi ke dalam empat divisi, yaitu Kimia Pangan, Mikrobiologi Pangan, Biokimia Pangan, dan Rekayasa Proses Pangan.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6 col-md-3">
                        <div class="profil-img">
                            <img src="<?=base_url()?>resources/img/logo himitepa.png">
                        </div>
                    </div>
                    <div class="col-lg-3 col-6 col-md-3">
                        <div class="profil-img">
                            <img src="<?=base_url()?>resources/img/logo ipb.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--End Profil Section-->

        <!--Sponsor Section-->
        <div class="sponsor-section">
            <div class="container">
                <div class="section-header text-center">
                    <p class="h4">sponsor</p>
                    <p class="h1">LCTIP XXIX</p>
                </div>
                <div class="sponsor-img"></div>
            </div>
        </div>
        <!--End Sponsor Section-->