<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function __construct(){
		parent:: __construct();
	}

	public function index()
	{
		$data['menu'] = 'home';
		$data['title'] = 'Home';

		$this->load->view('header', $data);
		$this->load->view('index');
		$this->load->view('footer');
	}

	public function competition()
	{
		$data['menu'] = 'event';
		$data['title'] = 'Competition';

		$this->load->view('header', $data);
		$this->load->view('competition');
		$this->load->view('footer');
	}

	public function conference()
	{
		$data['menu'] = 'event';
		$data['title'] = 'Seminar';

		$this->load->view('header', $data);
		$this->load->view('conference');
		$this->load->view('footer');
	}

	public function pare()
	{
		$data['menu'] = 'event';
		$data['title'] = 'Challenge';

		$this->load->view('header', $data);
		$this->load->view('pare');
		$this->load->view('footer');
	}

	public function faq()
	{
		$data['menu'] = 'faq';
		$data['title'] = 'Competition';

		$this->load->view('header', $data);
		$this->load->view('faq');
		$this->load->view('footer');
	}

	public function register()
	{
		$data['menu'] = 'register';
		$data['title'] = 'Register';

		$this->load->view('header', $data);
		$this->load->view('register');
		$this->load->view('footer');
	}

	public function uploadImage($file){
		$config['upload_path']          = './uploads/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 3000;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload($file)){
			$this->session->set_flashdata('msg', 'Data kamu gagal tersimpan!, Upload file tidak berhasil');
			redirect('registration');
		} else {
			return "uploads/".$this->upload->data()["file_name"];
		}
	}

	public function register_post(){
		$data = $this->input->post();
		$dataTeam["team_name"] = $data["team_name"];
		$dataTeam["school_name"] = $data["school_name"];
		$dataTeam["school_address"] = $data["school_address"];
		$dataTeam["school_email"] = $data["school_email"];
		$dataTeam["school_telp"] = $data["school_telp"];
		$dataTeam["school_region"] = $data["school_region"];
		$dataTeam["mentor_name"] = $data["mentor_name"];
		$dataTeam["mentor_telp"] = $data["mentor_telp"];
		$dataTeam["mentor_email"] = $data["mentor_email"];
		$dataTeam["mentor_nip"] = $data["mentor_nip"];
		$dataTeam["term1"] = $data["term1"];
		$dataTeam["term2"] = $data["term2"];
		$dataTeam["mentor_photo"] = $this->uploadImage('mentor_photo');
		$dataTeam["mentor_ktp"] = $this->uploadImage('mentor_ktp');
		$dataTeam["payment_proof"] = $this->uploadImage('payment_proof');
		$dataTeam["mesengger_letter"] = $this->uploadImage('mesengger_letter');
		$this->writeLog2("Data Team : ".json_encode($dataTeam));

		$team = $this->db->insert('team', $dataTeam);
		$teamId = $this->db->insert_id();

		//data ke 1
		$dataUser1["username"] = $data["username"];
		$dataUser1["password"] = sha1($data["password"]);
		$dataUser1["name"] = $data["name"];
		$dataUser1["nip"] = $data["nip"];
		$dataUser1["handphone"] = $data["handphone"];
		$dataUser1["email"] = $data["email"];
		$dataUser1["formal_photo"] = $this->uploadImage('formal_photo');
		$dataUser1["ktp_photo"] = $this->uploadImage('ktp_photo');

		$dataUser1["team"] = $teamId;
		$this->writeLog2("Data User 1 : ".json_encode($dataUser1));

		$team = $this->db->insert('user', $dataUser1);


		//data ke 2
		$dataUser2["username"] = $data["username2"];
		$dataUser2["password"] = sha1($data["password2"]);
		$dataUser2["name"] = $data["name2"];
		$dataUser2["nip"] = $data["nip2"];
		$dataUser2["handphone"] = $data["handphone2"];
		$dataUser2["email"] = $data["email2"];
		$dataUser2["formal_photo"] = $this->uploadImage('formal_photo2');
		$dataUser2["ktp_photo"] = $this->uploadImage('ktp_photo2');

		$dataUser2["team"] = $teamId;
		$this->writeLog2("Data User 2 : ".json_encode($dataUser2));

		$team = $this->db->insert('user', $dataUser2);


		//Data ke 3
		$dataUser3["username"] = $data["username3"];
		$dataUser3["password"] = sha1($data["password3"]);
		$dataUser3["name"] = $data["name3"];
		$dataUser3["nip"] = $data["nip3"];
		$dataUser3["handphone"] = $data["handphone3"];
		$dataUser3["email"] = $data["email3"];
		$dataUser3["formal_photo"] = $this->uploadImage('formal_photo3');
		$dataUser3["ktp_photo"] = $this->uploadImage('ktp_photo3');

		$dataUser3["team"] = $teamId;
		$this->writeLog2("Data User 3 : ".json_encode($dataUser3));

		$team = $this->db->insert('user', $dataUser3);

		if($team){
			$this->session->set_flashdata('msg', 'Data kamu telah tersimpan!');
		}

		redirect('registration');
	}

	private function writeLog2($text){
        $text = '['.date('d-m-Y H:i:s').'] '.$text.PHP_EOL;
        $file = './application/logs/registrationLog.txt';
        file_put_contents($file,$text, FILE_APPEND);
    }
}


